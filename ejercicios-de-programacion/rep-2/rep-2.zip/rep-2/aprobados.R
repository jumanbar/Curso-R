# Instrucciones: siendo cal el vector con las calificaciones de todos los estudiantes, y gen el vector 
# con el género de dichos estudiantes ("V" = varón y "M" = mujer), debe obtener los siguientes valores:
# p.apr*: porcentaje de estudiantes aprobados.
# Edite sólo la parte indicada más abajo, entremedio de las dos líneas horizontales (sin cambiar el texto
# de las propias líneas).
# Note además que en la evaluación automática cal y gen serán sustituidos por vectores creados
# aleatoriamente.
#===== Su código comienza aquí: =====#

p.apr <- 0

#====== Aquí finaliza su código =====#

