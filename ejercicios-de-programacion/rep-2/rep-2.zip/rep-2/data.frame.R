# Instrucciones:
# Los objetos cal, gen y ctg ya deben encontrarse en el área de trabajo para completar este 
# script. En caso contrario, corra "load('ej2.RData')" para cargar estos objetos ya preparados.

# Objetivos:
# datos.calif*: data.frame con las columnas "nota", "genero" y "franja", correspondientes a los vectores 
#              "cal", "gen" y "ctg" respectivamente.

# Note además que en la evaluación automática cal y gen serán vectores creados aleatoriamente.
#===== Su código comienza aquí: =====#

datos.calif <- 0

#====== Aquí finaliza su código =====#

