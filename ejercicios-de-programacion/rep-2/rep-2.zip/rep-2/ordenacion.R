# Instrucciones: 
# Los objetos cal, gen y ctg ya deben encontrarse en el área de trabajo para correr este 
# script. En caso contrario, corra "load('ej2.RData')" para cargar estos objetos ya preparados.

# Objetivos:
# datos.calif (ordenada)*: data.frame con las filas ordenadas en función del creciente de nota.

# Sugerencia (y por lo tanto opcional):
# orden.nota: vector con los índices necesarios para ordenar la columna nota (salida de función order).

# Recuerde que en la corrección los objetos cal y gen son creados nuevamente con generadores de números
# aleatorios.
#===== Su código comienza aquí: =====#

orden.nota <- 0

datos.calif <- 0

#====== Aquí finaliza su código =====#

