# Instrucciones: 
# Siendo cal el vector con las calificaciones de todos los estudiantes, y gen el vector 
# con el género de dichos estudiantes ("V" = varón y "M" = mujer), debe obtener los 
# siguientes valores:

# i*: posición a partir de la cual tomar los valores de ord.
#     ¡No olvide usar la función techo para obtener el i correcto!
# mejores*: vector con las notas del 25% mejor calificado del grupo de
#           estudiantes.

# Se sugiere (sin ser excluyente) crear el siguente objeto intermedio:
# ord: vector con los valores ordenados de menor a mayor de cal

# Note además que en la evaluación automática cal será un vector creado aleatoriamente.

#===== Su código comienza aquí: =====#

ord <- 0

i <- 0

mejores <- 0

#====== Aquí finaliza su código =====#

