# Rep. VI - ej. 1.a

# Instrucciones: 
# Debe utilizar un loop for para determinar la cantidad de valores mayores a 45
# en cada fila de la matriz datos. Las sumas se almacenarán en el vector out, 
# el cual debe tener la longitud adecuada antes de iniciarse el loop.

# Objetivos:
# Utilizar el loop for. No se permiten while, apply ni similares.
# out*: vector con las cantidades de valores mayores a 45 en 
#       las filas de la matriz datos.

# Generación de la matriz datos:
datos <- matrix(rpois(rpois(1, 125) * 15, 43), ncol = 15)

#===== Su código comienza aquí: =====#

out <- 0
for (  ) { # Debe usar el rango correcto de números enteros...
  
}

#===== Su código termina aquí =======#

