# Rep. VI - ej. 1.b

# Instrucciones: 
# Utilizar la función apply para obtener el mismo vector out que en el 
# ejercicio 1.a.

# Objetivos:
# Usar la función apply, no pueden haber alternativas, como while o for.
# f: función que suma la cantidad de valores mayores a 45 que tiene un vector 
#    cualquiera. No es obligatorio crear f: la función puede ser definida en 
#    la misma línea en que se ejecuta apply (buscar por "anonymous function" 
#    en la web)
# out*: vector con las cantidades de valores mayores a 45 en las filas de la 
# matriz datos.


#===== Su código comienza aquí: =====#

f <- 0   # f sería la función (opcional)

out <- 0 # Aquí debe usar la función apply

#===== Su código termina aquí =======#

