# Instrucciones: crear una función para estandarizar valores de vectores 
# numéricos. Dicha función debe llamarse "est" y tiene que tomar un único 
# argumento (un vector numeric), para devolver un vector numérico con los 
# valores estandarizados de dicho argumento.
# est*: función que toma un vector cualquiera y estandariza sus valores, 
#   según la fórmula expuesta en el repartido.

# Nota: en la evaluación automatizada se utilizan valores aleatorios para 
# determinar si el código es correcto.
#===== Su código comienza aquí: =====#

est <- 0

#====== Aquí finaliza su código =====#
