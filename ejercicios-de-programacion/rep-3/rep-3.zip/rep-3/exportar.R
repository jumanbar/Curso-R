# Rep. III - ej. 1.g

# Instrucciones: 
# Exportar la data.frame usaNorm al archivo "usa-norm.csv" siguiendo 
# los criterios indicados en la letra del repartido. El código generado 
# aquí debe partir de una data.frame llamada 'usaNorm' y debe terminar 
# exportando el archivo de texto plano con el nombre indicado y en la 
# carpeta del repartido ('rep-3').

# Objetivos:

# usa-norm.csv*: archivo de texto plano que debe quedar guardado en la 
#                carpeta del repartido (rep-3), cuyos valores son los de 
#                la data.frame usaNorm (el ejercicio parte del supuesto 
#                de que ya existe).

# Nota: en la evaluación automatizada se utiliza un nuevo archivo temporal 
# y no el que usted ve en la carpeta del repartido.

# El archivo usa-norm-ejemplo.csv sirve de ejemplo para comparar con su 
# solución final.

#===== Su código comienza aquí: =====#




#====== Aquí finaliza su código =====#

