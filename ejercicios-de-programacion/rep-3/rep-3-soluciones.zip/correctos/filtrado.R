# Instrucciones: eliminar las filas para las faltan datos de la columna 
# "Ingresos" de la data.frame 'usa2' (es decir, en donde hay NAs). El código 
# debe partir de usa2 y terminar en la creación de usa3.
# usa3*: data.frame modificada a partir de usa2 en la cual no se incluyen las 
#   observaciones en las que hay NA para la columna "Ingresos".

# Nota: el código creado debería funcionar independientemente de la 
# ubicación particular de los NA en la matriz usa2.

#===== Su código comienza aquí: =====#

usa3 <- subset(usa2, subset = !is.na(Ingresos))

#====== Aquí finaliza su código =====#
