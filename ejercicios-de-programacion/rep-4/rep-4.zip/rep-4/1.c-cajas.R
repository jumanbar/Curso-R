# Rep. IV - ej. 1.c

# Instrucciones: 
# El objetivo es crear un gráfico de cajas del peso de los participantes
# en función del genero de los mismos (ver la figura 2 de la letra).

# Se puede usar tanto plot como boxplot para hacer la tarea. La corrección
# automática se fijará en los textos del título y de los ejes.

# Objetivos:

# Título*: (no es un objeto a crear) debe ser "Peso en funcion del genero". 
#          Se omiten los tildes para evitar problemas de encoding.
# Etiquetas*: (no es un objeto a crear) los ejes deben estar etiquetados 
#             correctamente, con los textos "Genero" y "Peso (Kg)", horizontal 
#             y vertical respectivamente.

# Notas: 
# 1. una nueva data.frame magic es creada internamente en cada corrección.
# 2. este ejercicio parte de la base de que magic$genero es un factor tal como
#    se pide en el ejercicio 1.a.

#===== Su código comienza aquí: =====#



#====== Aquí finaliza su código =====#

