# Rep. IV - ej. 1.a

# Instrucciones: 
# Debe convertir la variable magic$genero en un factor de dos niveles: mujer
# y hombre, correspondientes a 1 y 2 en los valores originales.

# Objetivos:

# magic$genero*: variable factor con dos niveles: mujer y hombre

# Nota: una nueva data.frame magic es creada internamente en cada corrección.

#===== Su código comienza aquí: =====#





#====== Aquí finaliza su código =====#

