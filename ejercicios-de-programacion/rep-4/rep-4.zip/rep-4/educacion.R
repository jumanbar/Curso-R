#===== Su código comienza aquí: =====#

educacion <- function(  ){













}

#====== Aquí finaliza su código =====#






