#===== Su código comienza aquí: =====#

triangulo <- function(cat.ad, cat.op) {
  # Acepta como argumentos los valores de los dos catetos.


  
  
  
  
}

#===== Su código termina aquí =======#
