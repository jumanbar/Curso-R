# a.

magic <- 0

# b.

age <- 0

# c.



# d.



# e.

agef <- 0

# f.



# g.



# h.



# i.

peso.sexo <- 0

# j.

peso.hombre <- 0

peso.mujer <- 0

# k.



# l.

altura.peso <- 0

# m.

altura.peso2 <- 0

# n.

p <- seq(40, 120, by = 0.5)

ae <- 0

# o.

r2 <- 0

# p.



# q.



# r.



# s.



# t.
