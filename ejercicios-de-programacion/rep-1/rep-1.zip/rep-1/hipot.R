hipot <- function(cat.ad , cat.op) {
# Calcula la hipotenusa de un triángulo rectángulo a partir de los valores de
# los catetos, cat.ad y cat.op.
  out <- sqrt(cat.ad ** 2 + cat.op ** 2)
  out
}

#===== Su código comienza aquí: =====#

area <- function( ) {
# Acepta como argumentos los valores de los dos catetos.

}

co <- function( ) {
# Acepta como argumentos el valor del cateto adyacente y de la hipotenusa (¡en ese orden!)

}
#===== Su código termina aquí =======#

