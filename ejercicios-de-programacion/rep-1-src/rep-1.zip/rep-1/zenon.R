# Instrucciones: 
# Modifique el siguiente código para reproducir el nésimo término de la serie
# de Zenón.
# Luego determine cuál es el n mínimo tal que
#   1 - out < 1e-06
# (out es un valor que depende de n por supuesto)

# Objetos a obtener:
# n: tiene asignado un valor de 3 para empezar, pero usted lo deberá cambiar 
# para lograr el objetivo del problema (usando siempre valores enteros y positivos).
# e: representa los exponentes de cada término en la fórmula en de la letra (es
#    decir, 1, 2, 3, etc.. hasta n).
# s: vector final que se va a usar para la sumatoria
# out: resultado final de la sumatoria.

#===== Su código comienza aquí: =====# 

n <- 3

e <- 0

s <- 0

out <- 0

#====== Aquí finaliza su código =====#
