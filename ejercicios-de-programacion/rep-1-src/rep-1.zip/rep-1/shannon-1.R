# El vector de muestra "coleccion" se debe generar antes de escribir
# aquí, siguiendo el código de la letra:
# coleccion <- c(9, 6, 3, 3, 6, 1, 5, 5, 5, 3, 2, 7, 2, 1)

# Instrucciones:
# Modifique el código de abajo para obtener los siguentes
# objetos, siguiendo la ecuación 1 de la letra del repartido:

# n: vector con todos los n_i (="n subíndice i")
# N: cantidad total de objetos en la colección
# p: vector con todos los p_i
# H: índice de Shannon

# Usted deberá calcular el valor de H pero evitando usar la función "sum" y en
# cambio utilizando el producto interno o escalar, denotado por el operador %*%.
# Reuerde que las funciones "table" y "length" le pueden ser de mucha ayuda.

#===== Su código comienza aquí: =====#

n <- 0

N <- 0

p <- 0

H <- 0

#===== Aquí finaliza su código =====#
