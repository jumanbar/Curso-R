# Iniciación: es recomendable que usted comprenda las siguientes operaciones y
# las estructuras de los vectores cat.ad, cat.op y a, resultantes de ejecutar
# las líneas que se muestran en la letra (creando los objetos hip, cat.ad, cat.op
# y a).

# Instrucciones:
# Deberá usar which o which.max para encontrar la posición dentro
# del vector a en el que se encuentra el valor máximo de area.

# Modifique las líneas de abajo para obtener los siguientes objetos:

# i: posición en la que se encuentra el máximo de a 
# sol: valor de cateto adyacente para el que ocurre este máximo
# amax: valor máximo de área calculado ("i-ésimo valor de a ...")

#===== Su código comienza aquí: =====#

i    <- 0

sol  <- 0

amax <- 0

#====== Aquí finaliza su código =====#

