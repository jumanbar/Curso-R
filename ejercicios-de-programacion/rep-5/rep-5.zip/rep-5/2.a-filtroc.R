# Rep. V - ej. 2.a

# Instrucciones: 
# La función filtroc deberá tomar un data.frame (argumento "x") y seleccionar
# sólo aquellas columnas cuyos nombres contengan el string clave (argumento
# "clave"), ignorando diferencias entre mayúsculas y minúsculas.

# Argumentos:
# - x: data.frame cualquiera
# - clave: string usado para seleccionar columnas

# Salida:
# La salida será un data.frame conteniendo sólo aquellas columnas de la data.frame
# original seleccionadas.

#===== Su código comienza aquí: =====#

filtroc <- function(  ){



}

#====== Aquí finaliza su código =====#






