# Rep. V - ej. 2.c

# Instrucciones: 
# La función educacion calculará PC a partir de los promedios de
# TM y PA, para luego hacer una regresión de TA en función de PC.

# Argumentos:
# - x:     una data.frame cuyos nombres de columna tengan los 
#          prefijos TM, PA y TA.

# Salida:
# Una lista de clase 'edu' con dos componentes:
# - reg: el objeto de salida de la regresión lineal.
# - datos: la data.frame modificada (nuevas columnas: TM, PA y PC)

#===== Su código comienza aquí: =====#

educacion <- function(  ) {







  out <- 0
  class(out) <- "edu" # Asigna la clase 'edu' a la salida
  out
}

#===== Su código termina aquí =======#
