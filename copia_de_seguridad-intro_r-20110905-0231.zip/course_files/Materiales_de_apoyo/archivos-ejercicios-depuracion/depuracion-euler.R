eulerConv <- function(nmax=15, nmin=2, plot=TRUE, fun=estimaE1...) {
## Estima el valor de la constante de Euler, e, y lo compara con el valor
## "exp(1)", para todos los enteros nmin:nmax y muestra un gráfico con la
## convergencia a dicho valor.
  valores  <- nmin:nmax
  estimado <- sapply(valores, fun) # aplica la función a todos los valores
  if (plot) {
    plot(estimado ~ valores, ...)
    abline(h=exp(1), 0, lty=3)
  }
  diferencia <- abs(estimado - exp) # calcula la diferencia entre el valor
                                    # de e estimado y el valor "real"
  out <- list(e=estimado[length(valore)], estimados=estimado,
    diferencia=diferencia, valores=valores)
  # genera una salida de tipo lista
  return(out)
}

## Función que estima el valor de e siguiendo la convergencia de la serie:
## sum(1 / n!)
estimaE1 <- function(N)
  sum(1 / factorial(0:N))

## Función que estima el valor de e siguiendo la fórmula de Bernoulli
estimaE2 <- function(N)
  (1 + 1 / N) ^ N
