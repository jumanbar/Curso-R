fibonacci <- function(nfin=10, plot=TRUE, ...) {
## Devuelve un vector (invisible) con los primeros nfin valores de la
## serie de Fibonacci
  out <- numeric(nfin)
  out[1:2] <- 1 # los primeros dos valen 1
  for (i in 1:nfin - 2)
    out[i + 2] <- out[i + 1] + out[i]
  }
  titulo <- paste("Serie de Fibonacci (n = ", nfin, ")", sep="") 
  if (plot)
    plot(out, main=titulo, ...)
  invisible(out) # devuelve la salida de forma invisible para que no la
                 # imprima en la consola
}
