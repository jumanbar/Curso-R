distancias <- function(xy) {
## genera una matriz de las distancias entre puntos
## xy: matriz numérica de dos columnas (coordenadas)
  if (!(is.matrix(xy) || is.data.frame(xy)))
    stop("El argumento 'xy' no es matrix ni data.frame")
  out <- matrix(0, nrow(xy), ncol(xy))
  for (i in 1:nrow(xy))
    resta.x <- xy[, 1] - xy[i, 1]
    resta.y <- xy[, 2] - xy[i, 2]
    dista   <- sqrt(resta.x ^ 2 + restay ^ 2)
    out[i,] <- dista
  }
  return(out)
}
